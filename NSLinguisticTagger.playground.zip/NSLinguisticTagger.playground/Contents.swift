//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let options = NSLinguisticTagger.Options.omitWhitespace.rawValue | NSLinguisticTagger.Options.joinNames.rawValue

print (options)

let tagger = NSLinguisticTagger(tagSchemes: NSLinguisticTagger.availableTagSchemes(forLanguage: "en"), options: Int(options))

print (tagger)

let inputString = "overhead press"
tagger.string = inputString

let range = NSRange(location: 0, length: inputString.utf16.count)

tagger.enumerateTags(in: range, scheme: NSLinguisticTagSchemeNameTypeOrLexicalClass, options: NSLinguisticTagger.Options(rawValue: options)) { tag, tokenRange, sentenceRange, stop in
    let token = (inputString as NSString).substring(with: tokenRange)
    print("\(tag): \(token)")
}